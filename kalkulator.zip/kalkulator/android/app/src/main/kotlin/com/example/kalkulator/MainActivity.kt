package com.example.kalkulator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
