import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  final List<String> _history = [];

  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      CalculatorScreen(history: _history),
      HistoryScreen(history: _history),
      const ProfileScreen(),
    ];
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Kalkulator App")),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blueGrey),
              child: Text("Menu", style: TextStyle(fontSize: 24)),
            ),
            ListTile(
              title: const Text("Kalkulator"),
              onTap: () => _onItemTapped(0),
            ),
            ListTile(
              title: const Text("Riwayat"),
              onTap: () => _onItemTapped(1),
            ),
            ListTile(
              title: const Text("Profil"),
              onTap: () => _onItemTapped(2),
            ),
          ],
        ),
      ),
      body: Center(child: _pages[_selectedIndex]),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  final List<String> history;
  const CalculatorScreen({super.key, required this.history});

  @override
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expression = "";

  void _onButtonPressed(String value) {
    setState(() {
      if (value == "C") {
        _expression = "";
      } else if (value == "⌫") {
        if (_expression.isNotEmpty) {
          _expression = _expression.substring(0, _expression.length - 1);
        }
      } else if (value == "=") {
        try {
          Parser p = Parser();
          Expression exp = p.parse(_expression.replaceAll('x', '*'));
          ContextModel cm = ContextModel();
          double eval = exp.evaluate(EvaluationType.REAL, cm);
          String result = eval.toString();

          widget.history.insert(0, "$_expression = $result");
          if (widget.history.length > 5) {
            widget.history.removeLast();
          }

          _expression = result;
        } catch (e) {
          _expression = "Error";
        }
      } else {
        _expression += value;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(_expression, style: const TextStyle(fontSize: 36, color: Colors.white)),
        GridView.builder(
          shrinkWrap: true,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            childAspectRatio: 1.2,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: _buttons.length,
          itemBuilder: (context, index) {
            return _buildButton(_buttons[index]);
          },
        ),
      ],
    );
  }

  Widget _buildButton(String text) {
    return ElevatedButton(
      onPressed: text.isNotEmpty ? () => _onButtonPressed(text) : null,
      child: Text(text, style: const TextStyle(fontSize: 24)),
    );
  }
}

class HistoryScreen extends StatelessWidget {
  final List<String> history;
  const HistoryScreen({super.key, required this.history});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: history.length,
      itemBuilder: (context, index) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(history[index], style: const TextStyle(fontSize: 18)),
          ),
        );
      },
    );
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const CircleAvatar(
            radius: 50,
            backgroundImage: AssetImage('assets/didik.png'),
          ),
          const SizedBox(height: 20),
          const Text("Nama: Dimas Syahrul", style: TextStyle(fontSize: 24)),
          const Text("Kelas: XI RPL", style: TextStyle(fontSize: 24)),
          const SizedBox(height: 10),
          const Text("Deskripsi: Seorang pelajar yang menyukai pemrograman dan teknologi.",
              textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
          const SizedBox(height: 10),
          const Text("Email: dimassyahrul@gmail.com", style: TextStyle(fontSize: 18)),
          const Text("Telepon: 081234567890", style: TextStyle(fontSize: 18)),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Fitur Edit Profil belum tersedia")),
              );
            },
            child: const Text("Edit Profil"),
          ),
        ],
      ),
    );
  }
}

const List<String> _buttons = [
  "C", "⌫", "/", "x",
  "7", "8", "9", "-",
  "4", "5", "6", "+",
  "1", "2", "3", "=",
  "0", ".", ""
];
